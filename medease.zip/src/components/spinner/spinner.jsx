import React from 'react'

function Spinner() {
  return (
    <div>Spinner</div>
  )
}

export default Spinner