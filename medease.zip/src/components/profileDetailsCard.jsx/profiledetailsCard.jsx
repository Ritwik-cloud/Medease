// import React from 'react'
// import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
// import { Avatar, AvatarFallback, AvatarImage } from '@radix-ui/react-avatar'
// import { Badge, Camera, Edit, User, UserCircle } from 'lucide-react'
// import { Button } from '../ui/button'

// function ProfiledetailsCard({profileData}) {
//   return (
  
//   )
// }

// export default ProfiledetailsCard